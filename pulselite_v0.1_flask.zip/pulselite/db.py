import json
import oracledb
from pathlib import Path

CONFIG = None
APP_CONN = None

def load_config() -> dict:
    global CONFIG
    if CONFIG is None:
        CONFIG = json.loads(Path('config.json').read_text(encoding='utf-8'))
    return CONFIG

def _connect_new(cfg):
    mode = cfg.get('mode', 'thin').lower()
    user = cfg['user']
    password = cfg['password']
    if mode == 'tns':
        tns = cfg['tns']
        oracledb.init_oracle_client(lib_dir=tns['thick_client_dir'])
        dsn = tns['dsn_alias']
        con = oracledb.connect(user=user, password=password, dsn=dsn)
    else:
        thin = cfg['thin']
        dsn = oracledb.makedsn(thin['host'], thin['port'], service_name=thin['service_name'])
        con = oracledb.connect(user=user, password=password, dsn=dsn)
    con.autocommit = False
    return con

def app_connect():
    global APP_CONN
    cfg = load_config()['app_db']
    if APP_CONN is None:
        APP_CONN = _connect_new(cfg)
        return APP_CONN
    try:
        with APP_CONN.cursor() as c:
            c.execute("select 1 from dual")
            c.fetchone()
        return APP_CONN
    except Exception:
        APP_CONN = _connect_new(cfg)
        return APP_CONN

def qx(sql: str, params: tuple = ()):
    con = app_connect()
    with con.cursor() as cur:
        cur.execute(sql, params)
    con.commit()

def qf(sql: str, params: tuple = ()):
    con = app_connect()
    with con.cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchone()

def qa(sql: str, params: tuple = ()):
    con = app_connect()
    with con.cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()
