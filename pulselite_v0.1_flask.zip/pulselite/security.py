import os
from passlib.hash import bcrypt
from cryptography.fernet import Fernet

def hash_password(plain: str) -> str:
    return bcrypt.hash(plain)

def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.verify(plain, hashed)
    except Exception:
        return False

def _load_key(path: str) -> bytes:
    with open(path, 'rb') as f:
        return f.read().strip()

def encrypt_secret(plain: str, key_path: str) -> str:
    f = Fernet(_load_key(key_path))
    return f.encrypt(plain.encode()).decode()

def decrypt_secret(token: str, key_path: str) -> str:
    f = Fernet(_load_key(key_path))
    return f.decrypt(token.encode()).decode()
