# PulseLite (Flask, Python-only) — runs on http://0.0.0.0:5000

Pure Python web app (no IIS/Apache/Nginx). Backend DB is **Oracle**.
Includes Admin/Super console, Oracle module, SQL Server module, password reset via email, and background health checks.

## Quickstart
```bash
pip install -r requirements.txt
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())" > pulselite.key

# Edit config.json with Oracle app DB, SMTP, Flask secret.
# Create schema in Oracle:
#   run sql/00_schema.sql then sql/01_seed.sql as the app user (e.g., PULSE_APP).

python app.py   # serves on http://0.0.0.0:5000
```

## Notes
- Roles: ADMIN, SUPER, ORACLE, SQLSERVER. SUPER can access all modules.
- Passwords: bcrypt hashes. "Forgot password" sends a NEW random password to the stored email.
- Oracle targets: connect via TNS (thick) or thin (python-oracledb).
- SQL Server: pyodbc with ODBC Driver 18 (Windows).

Packaged on: 2025-11-04 23:29 UTC
