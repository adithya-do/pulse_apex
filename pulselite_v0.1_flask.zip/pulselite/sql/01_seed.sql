INSERT INTO app_roles (role_key) VALUES ('ADMIN');
INSERT INTO app_roles (role_key) VALUES ('SUPER');
INSERT INTO app_roles (role_key) VALUES ('ORACLE');
INSERT INTO app_roles (role_key) VALUES ('SQLSERVER');

INSERT INTO modules (module_key, module_name) VALUES ('ORACLE','Oracle Databases');
INSERT INTO modules (module_key, module_name) VALUES ('SQLSERVER','SQL Server Instances');

INSERT INTO app_users (login_id, full_name, email, pwd_hash, is_active)
VALUES ('admin', 'System Administrator', 'admin@example.com', 'SET_ME_FROM_APP', 'Y');

-- Grant all roles to admin (optional)
INSERT INTO user_roles (user_id, role_id)
SELECT u.user_id, r.role_id FROM app_users u CROSS JOIN app_roles r
WHERE u.login_id='admin';

COMMIT;
