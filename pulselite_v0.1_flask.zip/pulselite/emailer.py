import smtplib
from email.message import EmailMessage
from db import load_config

def send_mail(to_addr: str, subject: str, body: str):
    smtp = load_config()['smtp']
    msg = EmailMessage()
    msg['From'] = smtp['from_addr']
    msg['To'] = to_addr
    msg['Subject'] = subject
    msg.set_content(body)
    with smtplib.SMTP(smtp['host'], smtp['port']) as s:
        if smtp.get('use_tls', True):
            s.starttls()
        if smtp.get('username'):
            s.login(smtp['username'], smtp['password'])
        s.send_message(msg)
