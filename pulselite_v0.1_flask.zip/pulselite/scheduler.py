from apscheduler.schedulers.background import BackgroundScheduler
from db import app_connect, load_config
from security import decrypt_secret
from checks.oracle_check import run_check as ora_run
from checks.sqlserver_check import run_check as mss_run

_sched = None

def _tick_oracle():
    con = app_connect()
    with con.cursor() as cur:
        cur.execute("SELECT id FROM oracle_databases WHERE is_enabled='Y'")
        ids = [r[0] for r in cur.fetchall()]
    for tid in ids:
        try:
            ora_run(con, tid, load_config()['crypto']['fernet_key_file'])
        except Exception:
            pass

def _tick_sqlserver():
    con = app_connect()
    with con.cursor() as cur:
        cur.execute("SELECT id, instance_name, auth_mode, sql_username, sql_pwd_enc FROM sqlserver_instances WHERE is_enabled='Y'")
        rows = cur.fetchall()
    for row in rows:
        try:
            mss_run(con, row, lambda t: decrypt_secret(t, load_config()['crypto']['fernet_key_file']))
        except Exception:
            pass

def start_scheduler():
    global _sched
    if _sched:
        return _sched
    cfg = load_config()['scheduler']
    _sched = BackgroundScheduler()
    _sched.add_job(_tick_oracle, 'interval', seconds=int(cfg.get('oracle_interval_seconds', 300)), id='oracle_tick', coalesce=True, max_instances=1)
    _sched.add_job(_tick_sqlserver, 'interval', seconds=int(cfg.get('sqlserver_interval_seconds', 300)), id='sql_tick', coalesce=True, max_instances=1)
    _sched.start()
    return _sched
