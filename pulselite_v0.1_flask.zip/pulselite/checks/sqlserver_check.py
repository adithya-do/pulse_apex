import pyodbc

SQL_VER = "SELECT CONVERT(varchar(100), SERVERPROPERTY('ProductVersion'))"
SQL_LAST_FULL = """SELECT MAX(b.backup_finish_date) 
FROM msdb.dbo.backupset b WHERE b.type IN ('D','I')
"""
SQL_LAST_LOG = """SELECT MAX(b.backup_finish_date) FROM msdb.dbo.backupset b WHERE b.type='L'
"""

def _conn(instance: str, auth_mode: str, username: str|None, password: str|None):
    if auth_mode == 'WINDOWS':
        cs = f"Driver={{ODBC Driver 18 for SQL Server}};Server={instance};Trusted_Connection=Yes;Encrypt=No;"
    else:
        cs = f"Driver={{ODBC Driver 18 for SQL Server}};Server={instance};UID={username};PWD={password};Encrypt=No;"
    return pyodbc.connect(cs, timeout=10)

def run_check(con_app, target_row, dec_pwd):
    # target_row => (id, instance_name, auth_mode, sql_username, sql_pwd_enc)
    with con_app.cursor() as cur:
        rid_var = cur.var(int)
        cur.execute(
            "INSERT INTO health_check_runs(module_key, target_id, status) "
            "VALUES('SQLSERVER', :1, 'IN_PROGRESS') RETURNING run_id INTO :2",
            (target_row[0], rid_var)
        )
        try:
            run_id = int(rid_var.getvalue()[0])
        except Exception:
            cur.execute("SELECT MAX(run_id) FROM health_check_runs WHERE module_key='SQLSERVER' AND target_id=:1", (target_row[0],))
            run_id = cur.fetchone()[0]

        try:
            if target_row[2] == 'SQL':
                pwd = dec_pwd(target_row[4]) if target_row[4] else None
                cn = _conn(target_row[1], 'SQL', target_row[3], pwd)
            else:
                cn = _conn(target_row[1], 'WINDOWS', None, None)
            c = cn.cursor()
            c.execute(SQL_VER); ver = c.fetchone()[0]
            try:
                c.execute(SQL_LAST_FULL); last_full = c.fetchone()[0]
            except Exception:
                last_full = None
            try:
                c.execute(SQL_LAST_LOG); last_log = c.fetchone()[0]
            except Exception:
                last_log = None

            cur.execute(
                """                INSERT INTO sqlserver_check_results(run_id, instance_status, product_version, last_full_backup, last_log_backup)
                VALUES(:r,'UP',:v,:lf,:ll)
                """,                {"r": run_id, "v": ver, "lf": last_full, "ll": last_log}
            )
            cur.execute("UPDATE health_check_runs SET status='COMPLETED', finished_at=SYSTIMESTAMP WHERE run_id=:1", (run_id,))
            cur.execute("UPDATE sqlserver_instances SET last_check=SYSTIMESTAMP, last_error=NULL WHERE id=:1", (target_row[0],))
        except Exception as e:
            cur.execute("INSERT INTO sqlserver_check_results(run_id, instance_status) VALUES(:r,'DOWN')", {"r": run_id})
            cur.execute("UPDATE health_check_runs SET status='ERROR', error_message=:e, finished_at=SYSTIMESTAMP WHERE run_id=:1", (str(e), run_id))
            cur.execute("UPDATE sqlserver_instances SET last_check=SYSTIMESTAMP, last_error=:e WHERE id=:1", {"e": str(e), "1": target_row[0]})
        finally:
            con_app.commit()
    return run_id
