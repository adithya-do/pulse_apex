import oracledb
from db import load_config
from security import decrypt_secret

SQL_INSTANCE_STATUS = "SELECT STATUS FROM V$INSTANCE"
SQL_OPEN_MODE = "SELECT OPEN_MODE FROM V$DATABASE"
SQL_WORST_TS = "SELECT MAX(USED_PERCENT) FROM DBA_TABLESPACE_USAGE_METRICS"
SQL_ALL_TS_ONLINE = "SELECT CASE WHEN COUNT(*)=SUM(CASE WHEN STATUS='ONLINE' THEN 1 ELSE 0 END) THEN 'Y' ELSE 'N' END FROM DBA_TABLESPACES WHERE CONTENTS <> 'TEMPORARY'"
SQL_LAST_FULL = """SELECT MAX(START_TIME) FROM V$RMAN_BACKUP_JOB_DETAILS 
WHERE INPUT_TYPE IN ('DB FULL','DB INCR') AND STATUS='COMPLETED'
"""
SQL_LAST_ARCH = """SELECT MAX(START_TIME) FROM V$RMAN_BACKUP_JOB_DETAILS 
WHERE INPUT_TYPE='ARCHIVELOG' AND STATUS='COMPLETED'
"""

def _connect_target(row, key_path: str):
    mode, tns_alias, host, port, svc, user, enc = row
    pwd = decrypt_secret(enc, key_path)
    if mode == 'TNS':
        return oracledb.connect(user=user, password=pwd, dsn=tns_alias)
    else:
        dsn = oracledb.makedsn(host, int(port), service_name=svc)
        return oracledb.connect(user=user, password=pwd, dsn=dsn)

def run_check(con_app, target_id: int, key_path: str):
    with con_app.cursor() as cur:
        rid_var = cur.var(oracledb.NUMBER)
        cur.execute(
            "INSERT INTO health_check_runs(module_key, target_id, status) "
            "VALUES('ORACLE', :1, 'IN_PROGRESS') RETURNING run_id INTO :2",
            (target_id, rid_var)
        )
        run_id = int(rid_var.getvalue()[0])

        cur.execute(
            """            SELECT connect_mode, tns_alias, thin_host, thin_port, thin_service, common_user, common_pwd_enc
            FROM oracle_databases WHERE id=:id AND is_enabled='Y'
            """ ,
            {"id": target_id}
        )
        t = cur.fetchone()
        if not t:
            cur.execute(
                "UPDATE health_check_runs SET status='ERROR', error_message='Target not found or disabled', finished_at=SYSTIMESTAMP WHERE run_id=:1",
                (run_id,)
            )
            con_app.commit()
            return run_id

        cfg = load_config()
        try:
            with _connect_target(t, cfg['crypto']['fernet_key_file']) as c2:
                with c2.cursor() as c:
                    c.execute(SQL_INSTANCE_STATUS); ist = c.fetchone()[0]
                    c.execute(SQL_OPEN_MODE); om = c.fetchone()[0]
                    try:
                        c.execute(SQL_WORST_TS); worst = c.fetchone()[0]
                    except Exception:
                        worst = None
                    try:
                        c.execute(SQL_ALL_TS_ONLINE); ts_online = c.fetchone()[0]
                    except Exception:
                        ts_online = None
                    try:
                        c.execute(SQL_LAST_FULL); last_full = c.fetchone()[0]
                    except Exception:
                        last_full = None
                    try:
                        c.execute(SQL_LAST_ARCH); last_arch = c.fetchone()[0]
                    except Exception:
                        last_arch = None

            cur.execute(
                """                INSERT INTO oracle_check_results(run_id, db_status, instance_status, open_mode, worst_tablespace_pct, all_tablespaces_online, last_full_backup, last_arch_backup)
                VALUES(:r,'UP',:is_,:om,:wt,:onl,:lf,:la)
                """,                {"r": run_id, "is_": ist, "om": om, "wt": worst, "onl": ts_online, "lf": last_full, "la": last_arch}
            )
            cur.execute("UPDATE health_check_runs SET status='COMPLETED', finished_at=SYSTIMESTAMP WHERE run_id=:1", (run_id,))
            cur.execute("UPDATE oracle_databases SET last_check=SYSTIMESTAMP, last_error=NULL WHERE id=:1", (target_id,))
        except Exception as e:
            cur.execute("INSERT INTO oracle_check_results(run_id, db_status) VALUES(:r,'DOWN')", {"r": run_id})
            cur.execute("UPDATE health_check_runs SET status='ERROR', error_message=:e, finished_at=SYSTIMESTAMP WHERE run_id=:1", (str(e), run_id))
            cur.execute("UPDATE oracle_databases SET last_check=SYSTIMESTAMP, last_error=:e WHERE id=:1", {"e": str(e), "1": target_id})
        finally:
            con_app.commit()
    return run_id
