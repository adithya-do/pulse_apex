from __future__ import annotations
import functools, secrets, string
from flask import Flask, render_template, request, redirect, url_for, session, flash
from db import app_connect, qa, qf, qx, load_config
from security import hash_password, verify_password, encrypt_secret, decrypt_secret
from emailer import send_mail
from scheduler import start_scheduler

app = Flask(__name__)
app.config['SECRET_KEY'] = load_config()['flask']['secret_key']

# ------------------------- helpers -------------------------

def current_roles(login_id: str) -> list[str]:
    if not login_id:
        return []
    return [r[0] for r in qa(        """        SELECT r.role_key
        FROM app_roles r
        JOIN user_roles ur ON ur.role_id=r.role_id
        JOIN app_users u ON u.user_id=ur.user_id
        WHERE u.login_id=:1
        """, (login_id,)    )]

@app.context_processor
def inject_user():
    u = session.get('user')
    return dict(user=u, roles=current_roles(u))

def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        return view(*args, **kwargs)
    return wrapped

def roles_required(*need):
    def deco(view):
        @functools.wraps(view)
        def wrapped(*args, **kwargs):
            if 'user' not in session:
                return redirect(url_for('login'))
            roles = current_roles(session['user'])
            if 'SUPER' in roles or any(r in roles for r in need):
                return view(*args, **kwargs)
            flash('You do not have access to this module.', 'error')
            return redirect(url_for('dashboard'))
        return wrapped
    return deco

# ------------------------- auth ----------------------------

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        login_id = request.form.get('login_id','').strip()
        pwd = request.form.get('password','')
        r = qf("SELECT user_id, pwd_hash, is_active FROM app_users WHERE login_id=:1", (login_id,))
        if not r or r[2] != 'Y' or not verify_password(pwd, r[1]):
            flash('Invalid credentials', 'error')
            return render_template('login.html')
        session['user'] = login_id
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/forgot', methods=['POST'])
def forgot():
    login_id = request.form.get('login_id','').strip()
    r = qf("SELECT user_id, email FROM app_users WHERE login_id=:1", (login_id,))
    if not r:
        flash('Login ID not found', 'error')
        return redirect(url_for('login'))
    alphabet = string.ascii_letters + string.digits
    newpwd = ''.join(secrets.choice(alphabet) for _ in range(12))
    qx("UPDATE app_users SET pwd_hash=:1, updated_at=SYSTIMESTAMP WHERE user_id=:2", (hash_password(newpwd), r[0]))
    send_mail(r[1], 'PulseLite password reset', f'Your new PulseLite password: {newpwd}')
    flash('A new password has been emailed to you.', 'ok')
    return redirect(url_for('login'))

# ------------------------- dashboard ----------------------

@app.route('/')
@login_required
def dashboard():
    return render_template('dashboard.html')

# ------------------------- admin: users -------------------

@app.route('/admin/users')
@roles_required('ADMIN')
def admin_users():
    rows = qa("SELECT user_id, login_id, full_name, email, is_active FROM app_users ORDER BY login_id")
    data = []
    for uid, login_id, name, email, active in rows:
        rroles = ','.join([x[0] for x in qa(            "SELECT r.role_key FROM app_roles r JOIN user_roles ur ON ur.role_id=r.role_id WHERE ur.user_id=:1", (uid,)        )])
        data.append(dict(uid=uid, login=login_id, name=name, email=email, active=active, roles=rroles))
    return render_template('admin_users.html', users=data)

@app.route('/admin/users/upsert', methods=['POST'])
@roles_required('ADMIN')
def admin_users_upsert():
    login_id = request.form['login_id'].strip()
    full_name = request.form['full_name'].strip()
    email = request.form['email'].strip()
    role = request.form['role']
    r = qf("SELECT user_id FROM app_users WHERE login_id=:1", (login_id,))
    if r:
        qx("UPDATE app_users SET full_name=:1, email=:2, updated_at=SYSTIMESTAMP WHERE user_id=:3", (full_name, email, r[0]))
        uid = r[0]
    else:
        qx("INSERT INTO app_users(login_id, full_name, email, pwd_hash) VALUES(:1,:2,:3,:4)", (login_id, full_name, email, hash_password('Welcome1!')))
        uid = qf("SELECT user_id FROM app_users WHERE login_id=:1", (login_id,))[0]
    rid = qf("SELECT role_id FROM app_roles WHERE role_key=:1", (role,))[0]
    qx("DELETE FROM user_roles WHERE user_id=:1 AND role_id=:2", (uid, rid))
    qx("INSERT INTO user_roles(user_id, role_id) VALUES(:1,:2)", (uid, rid))
    flash('User saved', 'ok')
    return redirect(url_for('admin_users'))

@app.route('/admin/users/reset/<login_id>', methods=['POST'])
@roles_required('ADMIN')
def admin_users_reset(login_id):
    alphabet = string.ascii_letters + string.digits
    newpwd = ''.join(secrets.choice(alphabet) for _ in range(12))
    qx("UPDATE app_users SET pwd_hash=:1, updated_at=SYSTIMESTAMP WHERE login_id=:2", (hash_password(newpwd), login_id))
    r = qf("SELECT email FROM app_users WHERE login_id=:1", (login_id,))
    if r: send_mail(r[0], 'PulseLite password reset', f'Your new password: {newpwd}')
    flash('Password reset sent', 'ok')
    return redirect(url_for('admin_users'))

# ------------------------- oracle module ------------------

@app.route('/oracle')
@roles_required('ORACLE')
def oracle_list():
    sql = """    WITH last_run AS (
      SELECT target_id, MAX(run_id) run_id
      FROM health_check_runs
      WHERE module_key='ORACLE'
      GROUP BY target_id
    )
    SELECT o.id, o.db_name, o.environment, o.host, o.connect_mode,
           TO_CHAR(o.last_check,'YYYY-MM-DD HH24:MI'), o.last_error,
           r.status,
           res.instance_status, res.open_mode, res.worst_tablespace_pct, res.all_tablespaces_online,
           res.last_full_backup, res.last_arch_backup
    FROM oracle_databases o
    LEFT JOIN last_run lr ON lr.target_id=o.id
    LEFT JOIN health_check_runs r ON r.run_id=lr.run_id
    LEFT JOIN oracle_check_results res ON res.run_id=lr.run_id
    ORDER BY o.id
    """    rows = qa(sql)
    return render_template('oracle_list.html', rows=rows)

@app.route('/oracle/upsert', methods=['POST'])
@roles_required('ORACLE')
def oracle_upsert():
    o = request.form
    enc = encrypt_secret(o['common_pwd'], load_config()['crypto']['fernet_key_file']) if o.get('common_pwd') else None
    r = qf("SELECT id FROM oracle_databases WHERE db_name=:1", (o['db_name'],))
    if r:
        params = (o['environment'], o['host'], o['connect_mode'], o.get('tns_alias') or None,                  o.get('thin_host') or None, int(o.get('thin_port') or 1521), o.get('thin_service') or None,                  o['common_user'])
        if enc:
            qx("""                UPDATE oracle_databases
                SET environment=:1, host=:2, connect_mode=:3, tns_alias=:4,
                    thin_host=:5, thin_port=:6, thin_service=:7, common_user=:8, common_pwd_enc=:9
                WHERE id=:10
            """, params + (enc, r[0]))
        else:
            qx("""                UPDATE oracle_databases
                SET environment=:1, host=:2, connect_mode=:3, tns_alias=:4,
                    thin_host=:5, thin_port=:6, thin_service=:7, common_user=:8
                WHERE id=:9
            """, params + (r[0],))
    else:
        qx("""            INSERT INTO oracle_databases(db_name, environment, host, connect_mode, tns_alias,
                thin_host, thin_port, thin_service, common_user, common_pwd_enc)
            VALUES(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10)
        """, (o['db_name'], o['environment'], o['host'], o['connect_mode'], o.get('tns_alias'),               o.get('thin_host'), int(o.get('thin_port') or 1521), o.get('thin_service'), o['common_user'], enc))
    flash('Oracle DB saved', 'ok')
    return redirect(url_for('oracle_list'))

@app.route('/oracle/run/<int:oid>', methods=['POST'])
@roles_required('ORACLE')
def oracle_run(oid):
    from checks.oracle_check import run_check
    con = app_connect()
    rid = run_check(con, oid, load_config()['crypto']['fernet_key_file'])
    flash(f'Oracle check started/run_id={rid}', 'ok')
    return redirect(url_for('oracle_list'))

# ------------------------- sql server module --------------

@app.route('/sqlserver')
@roles_required('SQLSERVER')
def sqlserver_list():
    sql = """    WITH last_run AS (
      SELECT target_id, MAX(run_id) run_id
      FROM health_check_runs
      WHERE module_key='SQLSERVER'
      GROUP BY target_id
    )
    SELECT s.id, s.instance_name, s.environment, s.host, s.auth_mode,
           TO_CHAR(s.last_check,'YYYY-MM-DD HH24:MI'), s.last_error,
           r.status,
           res.product_version, res.last_full_backup, res.last_log_backup
    FROM sqlserver_instances s
    LEFT JOIN last_run lr ON lr.target_id=s.id
    LEFT JOIN health_check_runs r ON r.run_id=lr.run_id
    LEFT JOIN sqlserver_check_results res ON res.run_id=lr.run_id
    ORDER BY s.id
    """    rows = qa(sql)
    return render_template('sqlserver_list.html', rows=rows)

@app.route('/sqlserver/upsert', methods=['POST'])
@roles_required('SQLSERVER')
def sqlserver_upsert():
    s = request.form
    enc = encrypt_secret(s['sql_password'], load_config()['crypto']['fernet_key_file']) if s.get('sql_password') else None
    r = qf("SELECT id FROM sqlserver_instances WHERE instance_name=:1", (s['instance_name'],))
    if r:
        if enc:
            qx("UPDATE sqlserver_instances SET environment=:1, host=:2, auth_mode=:3, sql_username=:4, sql_pwd_enc=:5 WHERE id=:6",               (s['environment'], s['host'], s['auth_mode'], s.get('sql_username'), enc, r[0]))
        else:
            qx("UPDATE sqlserver_instances SET environment=:1, host=:2, auth_mode=:3, sql_username=:4 WHERE id=:5",               (s['environment'], s['host'], s['auth_mode'], s.get('sql_username'), r[0]))
    else:
        qx("INSERT INTO sqlserver_instances(instance_name, environment, host, auth_mode, sql_username, sql_pwd_enc) VALUES(:1,:2,:3,:4,:5,:6)",           (s['instance_name'], s['environment'], s['host'], s['auth_mode'], s.get('sql_username'), enc))
    flash('SQL Server instance saved', 'ok')
    return redirect(url_for('sqlserver_list'))

@app.route('/sqlserver/run/<int:sid>', methods=['POST'])
@roles_required('SQLSERVER')
def sqlserver_run(sid):
    from checks.sqlserver_check import run_check
    con = app_connect()
    with con.cursor() as cur:
        cur.execute("SELECT id, instance_name, auth_mode, sql_username, sql_pwd_enc FROM sqlserver_instances WHERE id=:1", (sid,))
        row = cur.fetchone()
    rid = run_check(con, row, lambda t: decrypt_secret(t, load_config()['crypto']['fernet_key_file']))
    flash(f'SQL Server check started/run_id={rid}', 'ok')
    return redirect(url_for('sqlserver_list'))

# ------------------------- app bootstrap ------------------

@app.before_first_request
def _start_bg():
    start_scheduler()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
