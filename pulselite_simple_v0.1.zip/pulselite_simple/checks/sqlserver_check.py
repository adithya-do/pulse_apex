\
import pyodbc

SQL_VER = "SELECT CONVERT(varchar(100), SERVERPROPERTY('ProductVersion'))"
SQL_LAST_FULL = \"\"\"\
SELECT MAX(b.backup_finish_date) 
FROM msdb.dbo.backupset b WHERE b.type IN ('D','I')
\"\"\"
SQL_LAST_LOG = \"\"\"\
SELECT MAX(b.backup_finish_date) FROM msdb.dbo.backupset b WHERE b.type='L'
\"\"\"

def _conn(instance: str, auth_mode: str, username: str|None, password: str|None):
    if auth_mode == 'WINDOWS':
        cs = f"Driver={{ODBC Driver 18 for SQL Server}};Server={instance};Trusted_Connection=Yes;Encrypt=No;"
    else:
        cs = f"Driver={{ODBC Driver 18 for SQL Server}};Server={instance};UID={username};PWD={password};Encrypt=No;"
    return pyodbc.connect(cs, timeout=10)

def run_once(cfg: dict) -> dict:
    out = {"instance_status":"DOWN","product_version":None,"last_full_backup":None,"last_log_backup":None,"error":None}
    try:
        cn = _conn(cfg["instance_name"], cfg["auth_mode"], cfg.get("sql_username"), cfg.get("sql_password"))
        c = cn.cursor()
        out["instance_status"] = "UP"
        try: c.execute(SQL_VER); out["product_version"] = c.fetchone()[0]
        except Exception: pass
        try: c.execute(SQL_LAST_FULL); out["last_full_backup"] = c.fetchone()[0]
        except Exception: pass
        try: c.execute(SQL_LAST_LOG); out["last_log_backup"] = c.fetchone()[0]
        except Exception: pass
    except Exception as e:
        out["error"] = str(e)
    return out
