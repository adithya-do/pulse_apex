\
import oracledb

SQL_INSTANCE_STATUS = "SELECT STATUS FROM V$INSTANCE"
SQL_OPEN_MODE = "SELECT OPEN_MODE FROM V$DATABASE"
SQL_WORST_TS = "SELECT MAX(USED_PERCENT) FROM DBA_TABLESPACE_USAGE_METRICS"
SQL_ALL_TS_ONLINE = "SELECT CASE WHEN COUNT(*)=SUM(CASE WHEN STATUS='ONLINE' THEN 1 ELSE 0 END) THEN 'Y' ELSE 'N' END FROM DBA_TABLESPACES WHERE CONTENTS <> 'TEMPORARY'"
SQL_LAST_FULL = \"\"\"\
SELECT MAX(START_TIME) FROM V$RMAN_BACKUP_JOB_DETAILS 
WHERE INPUT_TYPE IN ('DB FULL','DB INCR') AND STATUS='COMPLETED'
\"\"\"
SQL_LAST_ARCH = \"\"\"\
SELECT MAX(START_TIME) FROM V$RMAN_BACKUP_JOB_DETAILS 
WHERE INPUT_TYPE='ARCHIVELOG' AND STATUS='COMPLETED'
\"\"\"

def connect_target(cfg: dict):
    mode = cfg.get("connect_mode","THIN").upper()
    user = cfg["common_user"]
    pwd  = cfg["common_pwd"]
    if mode == "TNS":
        dsn = cfg["tns_alias"]
        return oracledb.connect(user=user, password=pwd, dsn=dsn)
    else:
        host = cfg["thin_host"]; port = int(cfg.get("thin_port",1521)); svc = cfg["thin_service"]
        dsn = oracledb.makedsn(host, port, service_name=svc)
        return oracledb.connect(user=user, password=pwd, dsn=dsn)

def run_once(cfg: dict) -> dict:
    out = {"db_status":"DOWN","instance_status":None,"open_mode":None,"worst_tablespace_pct":None,"all_tablespaces_online":None,"last_full_backup":None,"last_arch_backup":None,"error":None}
    try:
        with connect_target(cfg) as cn:
            out["db_status"] = "UP"
            with cn.cursor() as c:
                try: c.execute(SQL_INSTANCE_STATUS); out["instance_status"] = c.fetchone()[0]
                except Exception: pass
                try: c.execute(SQL_OPEN_MODE); out["open_mode"] = c.fetchone()[0]
                except Exception: pass
                try: c.execute(SQL_WORST_TS); out["worst_tablespace_pct"] = c.fetchone()[0]
                except Exception: pass
                try: c.execute(SQL_ALL_TS_ONLINE); out["all_tablespaces_online"] = c.fetchone()[0]
                except Exception: pass
                try: c.execute(SQL_LAST_FULL); out["last_full_backup"] = c.fetchone()[0]
                except Exception: pass
                try: c.execute(SQL_LAST_ARCH); out["last_arch_backup"] = c.fetchone()[0]
                except Exception: pass
    except Exception as e:
        out["error"] = str(e)
    return out
