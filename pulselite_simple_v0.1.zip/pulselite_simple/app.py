\
from flask import Flask, render_template, request, redirect, url_for, session, flash
from storage import get_user, list_users, upsert_user, delete_user, list_oracle, upsert_oracle, delete_oracle, list_sql, upsert_sql, delete_sql, sha256
from checks.oracle_check import run_once as ora_check
from checks.sqlserver_check import run_once as mss_check

app = Flask(__name__)
app.secret_key = 'pulselite-simple'

def login_required(fn):
    from functools import wraps
    @wraps(fn)
    def w(*a, **k):
        if 'user' not in session:
            return redirect(url_for('login'))
        return fn(*a, **k)
    return w

def roles_required(*need):
    def deco(fn):
        from functools import wraps
        @wraps(fn)
        def w(*a, **k):
            if 'user' not in session:
                return redirect(url_for('login'))
            roles = session.get('roles', [])
            if 'SUPER' in roles or any(r in roles for r in need):
                return fn(*a, **k)
            flash('No access to this module', 'error')
            return redirect(url_for('dashboard'))
        return w
    return deco

@app.context_processor
def inject_user():
    return dict(user=session.get('user'), roles=session.get('roles', []))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        login_id = request.form.get('login_id','').strip()
        pwd = request.form.get('password','')
        u = get_user(login_id)
        if not u:
            flash('Invalid credentials', 'error'); return render_template('login.html')
        if login_id == 'admin':
            if pwd != 'admin':
                flash('Invalid credentials', 'error'); return render_template('login.html')
        else:
            if not u.get('password_sha256') or u['password_sha256'] != sha256(pwd):
                flash('Invalid credentials', 'error'); return render_template('login.html')
        session['user'] = login_id
        roles = ['ORACLE','SQLSERVER','SUPER'] if login_id=='admin' else u.get('roles', [])
        session['roles'] = roles
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/admin/users')
@roles_required('SUPER')
def admin_users():
    return render_template('admin_users.html', users=list_users())

@app.route('/admin/users/save', methods=['POST'])
@roles_required('SUPER')
def admin_users_save():
    login_id = request.form['login_id'].strip()
    password = request.form.get('password','')
    roles = request.form.getlist('roles')
    upsert_user(login_id, password, roles)
    flash('User saved', 'ok')
    return redirect(url_for('admin_users'))

@app.route('/admin/users/delete/<login_id>', methods=['POST'])
@roles_required('SUPER')
def admin_users_delete(login_id):
    delete_user(login_id)
    flash('User deleted', 'ok')
    return redirect(url_for('admin_users'))

@app.route('/oracle')
@roles_required('ORACLE','SUPER')
def oracle_list_page():
    return render_template('oracle_list.html', rows=list_oracle(), last=session.pop('last_ora', None))

@app.route('/oracle/save', methods=['POST'])
@roles_required('ORACLE','SUPER')
def oracle_save():
    obj = {
        "db_name": request.form['db_name'].strip(),
        "environment": request.form.get('environment','NON-PROD'),
        "host": request.form.get('host','').strip(),
        "connect_mode": request.form.get('connect_mode','THIN'),
        "tns_alias": request.form.get('tns_alias','').strip(),
        "thin_host": request.form.get('thin_host','').strip(),
        "thin_port": int(request.form.get('thin_port','1521') or 1521),
        "thin_service": request.form.get('thin_service','').strip(),
        "common_user": request.form.get('common_user','').strip(),
        "common_pwd": request.form.get('common_pwd','').strip()
    }
    upsert_oracle(obj)
    flash('Oracle target saved', 'ok')
    return redirect(url_for('oracle_list_page'))

@app.route('/oracle/delete/<db_name>', methods=['POST'])
@roles_required('ORACLE','SUPER')
def oracle_delete(db_name):
    delete_oracle(db_name)
    flash('Oracle target deleted', 'ok')
    return redirect(url_for('oracle_list_page'))

@app.route('/oracle/run/<db_name>', methods=['POST'])
@roles_required('ORACLE','SUPER')
def oracle_run(db_name):
    cfg = next((t for t in list_oracle() if t['db_name']==db_name), None)
    if not cfg:
        flash('Target not found', 'error'); return redirect(url_for('oracle_list_page'))
    res = ora_check(cfg)
    session['last_ora'] = {"name": db_name, "result": res}
    return redirect(url_for('oracle_list_page'))

@app.route('/sqlserver')
@roles_required('SQLSERVER','SUPER')
def sql_list_page():
    return render_template('sqlserver_list.html', rows=list_sql(), last=session.pop('last_sql', None))

@app.route('/sqlserver/save', methods=['POST'])
@roles_required('SQLSERVER','SUPER')
def sql_save():
    obj = {
        "instance_name": request.form['instance_name'].strip(),
        "environment": request.form.get('environment','NON-PROD'),
        "host": request.form.get('host','').strip(),
        "auth_mode": request.form.get('auth_mode','WINDOWS'),
        "sql_username": request.form.get('sql_username','').strip(),
        "sql_password": request.form.get('sql_password','').strip()
    }
    upsert_sql(obj)
    flash('SQL Server target saved', 'ok')
    return redirect(url_for('sql_list_page'))

@app.route('/sqlserver/delete/<path:instance_name>', methods=['POST'])
@roles_required('SQLSERVER','SUPER')
def sql_delete(instance_name):
    delete_sql(instance_name)
    flash('SQL Server target deleted', 'ok')
    return redirect(url_for('sql_list_page'))

@app.route('/sqlserver/run/<path:instance_name>', methods=['POST'])
@roles_required('SQLSERVER','SUPER')
def sql_run(instance_name):
    cfg = next((t for t in list_sql() if t['instance_name']==instance_name), None)
    if not cfg:
        flash('Target not found', 'error'); return redirect(url_for('sql_list_page'))
    res = mss_check(cfg)
    session['last_sql'] = {"name": instance_name, "result": res}
    return redirect(url_for('sql_list_page'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
