# PulseLite Simple (Flask, JSON storage) — http://0.0.0.0:5000

Super-simple build:
- **No Oracle backend**. Config & users & targets saved in local **JSON** (`data/`).
- **No history**. Checks run on-demand and show results immediately.
- **Admin login**: username `admin`, password `admin` (always).
- Module roles: `ORACLE`, `SQLSERVER`. Admin has all.

## Quickstart
```bash
pip install -r requirements.txt
python app.py   # serves on http://0.0.0.0:5000
```
Optional: Install ODBC Driver 18 for SQL Server (Windows) for SQL checks.

Packaged: 2025-11-04 23:55 UTC
