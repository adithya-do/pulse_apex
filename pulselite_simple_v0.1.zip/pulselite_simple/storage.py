\
import json, os, hashlib, threading
from pathlib import Path

DATA_DIR = Path('./data')
USERS_FILE = DATA_DIR / 'users.json'
ORACLE_FILE = DATA_DIR / 'oracle_targets.json'
SQL_FILE = DATA_DIR / 'sqlserver_targets.json'

_lock = threading.Lock()

def _ensure_files():
    DATA_DIR.mkdir(exist_ok=True)
    if not USERS_FILE.exists():
        USERS_FILE.write_text(json.dumps({
            "users": []
        }, indent=2))
    if not ORACLE_FILE.exists():
        ORACLE_FILE.write_text(json.dumps({"targets":[]}, indent=2))
    if not SQL_FILE.exists():
        SQL_FILE.write_text(json.dumps({"targets":[]}, indent=2))

def _load(path, default):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return default

def _save(path, data):
    Path(path).write_text(json.dumps(data, indent=2), encoding='utf-8')

def sha256(s: str) -> str:
    import hashlib
    return hashlib.sha256(s.encode()).hexdigest()

def list_users():
    _ensure_files()
    data = _load(USERS_FILE, {"users":[]})
    return data["users"]

def upsert_user(login: str, password_plain: str, roles: list[str]):
    if login == 'admin':
        return
    _ensure_files()
    with _lock:
        data = _load(USERS_FILE, {"users":[]})
        for u in data["users"]:
            if u["login"] == login:
                if password_plain:
                    u["password_sha256"] = sha256(password_plain)
                u["roles"] = roles
                _save(USERS_FILE, data)
                return
        data["users"].append({
            "login": login,
            "password_sha256": sha256(password_plain) if password_plain else "",
            "roles": roles
        })
        _save(USERS_FILE, data)

def delete_user(login: str):
    if login == 'admin':
        return
    _ensure_files()
    with _lock:
        data = _load(USERS_FILE, {"users":[]})
        data["users"] = [u for u in data["users"] if u["login"] != login]
        _save(USERS_FILE, data)

def get_user(login: str):
    if login == 'admin':
        return {"login":"admin", "password_sha256": sha256("admin"), "roles":["ORACLE","SQLSERVER","SUPER"], "is_admin": True}
    _ensure_files()
    data = _load(USERS_FILE, {"users":[]})
    for u in data["users"]:
        if u["login"] == login:
            u2 = dict(u)
            u2["is_admin"] = False
            return u2
    return None

def list_oracle():
    _ensure_files()
    return _load(ORACLE_FILE, {"targets":[]})["targets"]

def upsert_oracle(obj: dict):
    _ensure_files()
    with _lock:
        data = _load(ORACLE_FILE, {"targets":[]})
        for t in data["targets"]:
            if t["db_name"] == obj["db_name"]:
                t.update(obj)
                _save(ORACLE_FILE, data)
                return
        data["targets"].append(obj)
        _save(ORACLE_FILE, data)

def delete_oracle(db_name: str):
    _ensure_files()
    with _lock:
        data = _load(ORACLE_FILE, {"targets":[]})
        data["targets"] = [t for t in data["targets"] if t["db_name"] != db_name]
        _save(ORACLE_FILE, data)

def list_sql():
    _ensure_files()
    return _load(SQL_FILE, {"targets":[]})["targets"]

def upsert_sql(obj: dict):
    _ensure_files()
    with _lock:
        data = _load(SQL_FILE, {"targets":[]})
        for t in data["targets"]:
            if t["instance_name"] == obj["instance_name"]:
                t.update(obj)
                _save(SQL_FILE, data)
                return
        data["targets"].append(obj)
        _save(SQL_FILE, data)

def delete_sql(instance_name: str):
    _ensure_files()
    with _lock:\
        data = _load(SQL_FILE, {"targets":[]})
        data["targets"] = [t for t in data["targets"] if t["instance_name"] != instance_name]
        _save(SQL_FILE, data)
